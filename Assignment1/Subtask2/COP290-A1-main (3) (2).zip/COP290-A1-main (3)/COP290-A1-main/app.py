from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
import os
import yfinance as yf
from datetime import date, datetime
from jugaad_data.nse import NSELive

#xxxxxxxxxxxxxxxxxxxx-------------------------------
#Retrieval of stock data

def get_listing_date(symbol):
    n = NSELive()
    q = n.stock_quote(symbol)
    if 'metadata' in q:
        date_start = q['metadata']['listingDate']
    else:

        date_start = '01-Jan-2023'
    date_temp = datetime.strptime(date_start, '%d-%b-%Y')
    date_start = date_temp.strftime('%Y-%m-%d')  
    return date_start

def get_last_date_from_csv(csv_filename):
    with open(csv_filename, 'r') as file:
        last_line = file.readlines()[-2]
        last_date = last_line.split(',')[0]
        print(last_line)
    return last_date

def stock_data(symbol, interval):
    date_today = date.today().strftime("%Y-%m-%d")
    csv_filename = f"static/{symbol}_{interval}.csv"

    if os.path.exists(csv_filename):
        last_date = get_last_date_from_csv(csv_filename)
    else:
        last_date = get_listing_date(symbol)

    new_data = yf.download(symbol+".ns", start=last_date, end=date_today, interval=interval)
    new_data = new_data.reset_index()
    new_data = new_data[['Date', 'Open', 'High', 'Low', 'Close']]
    for col in ['Open', 'High', 'Low', 'Close']:
        new_data[col] = round(new_data[col], 2)

    new_data.to_csv(csv_filename, mode='a', header=False, index=False)
    return csv_filename

def get_ltp(symbol):
    nse_live = NSELive()
    stock_data = nse_live.stock_quote(symbol)
    ltp = stock_data.get('priceInfo', {}).get('lastPrice', None)
    return ltp

app = Flask(__name__)
app.secret_key = 'your_secret_key'  
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    watchlist = db.Column(db.String(500), default='')

class Portfolio(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    symbol = db.Column(db.String(20), nullable=False)
    purchase_date = db.Column(db.Date, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    purchase_price = db.Column(db.Float, nullable=False)
    ltp = db.Column(db.Float)
    current_value = db.Column(db.Float)
    profit_loss = db.Column(db.Float)
    profit_loss_percentage = db.Column(db.Float)

with app.app_context():
    db.create_all()

with app.app_context():
    db.create_all()

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')

        new_user = User(username=username, password_hash=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful! Please login.')
        return redirect(url_for('index'))

    return render_template('register.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    user = User.query.filter_by(username=username).first()

    if user and check_password_hash(user.password_hash, password):
        session['user_id'] = user.id
        session['username'] = user.username
        session['watchlist'] = user.watchlist.split(',') if user.watchlist else []  
        session['comparison'] = []
        return redirect(url_for('dashboard'))
    else:
        flash('Invalid username or password')
        return redirect(url_for('index'))


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('watchlist', None)
    return redirect(url_for('index'))

#xxxxxxxxxxxxxxxxxxxx-------------------------------
#Dashboard and watchlist

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' in session:
        return render_template('dashboard.html', username=session['username'], watchlist_symbols=session['watchlist'])

    return redirect(url_for('index'))


@app.route('/update_watchlist', methods=['POST'])
def update_watchlist():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])

        if request.method == 'POST':
            action = request.form.get('action')
            symbol = request.form.get('symbol')

            if action == 'add':
                if user.watchlist == '':
                    user.watchlist = f"{symbol}"
                if symbol not in user.watchlist:
                    user.watchlist += f",{symbol}"
            elif action == 'remove':
                user.watchlist = ','.join([s for s in user.watchlist.split(',') if s != symbol])

            session['watchlist'] = user.watchlist.split(',') if user.watchlist else []
            db.session.commit()

    return redirect(url_for('dashboard'))

#xxxxxxxxxxxxxxxxxxxx-------------------------------
#Filter Stocks

@app.route('/filter', methods=['GET', 'POST'])
def filter():
    return render_template('filter.html')

def get_stocks_in_range(lower_bound, upper_bound, option):
    nifty_50_stocks_df = pd.read_csv('ind_nifty50list.csv')
    nifty_50_stocks = nifty_50_stocks_df['Symbol'].tolist()

    stocks_in_range = []
    if(option == 1):
        for symbol in nifty_50_stocks:
            data2 = yf.Ticker(symbol+".ns").info
            pe_ratio = data2.get('trailingPE', None)
            if pe_ratio is not None and lower_bound <= pe_ratio <= upper_bound:
                stocks_in_range.append({
                    "Symbol": symbol,
                    "Value": round(pe_ratio, 2)
                })

    elif(option == 2):
        for symbol in nifty_50_stocks:
            data2 = yf.Ticker(symbol+".ns").info
            pb_ratio = data2.get('priceToBook', None)
            if pb_ratio is not None and lower_bound <= pb_ratio <= upper_bound:
                stocks_in_range.append({
                    "Symbol": symbol,
                    "Value": round(pb_ratio, 2)
                })

    elif(option == 3):
        for symbol in nifty_50_stocks:
            data2 = yf.Ticker(symbol+".ns").info
            market_cap = data2.get('marketCap', 'Not available')/(10**7)
            if market_cap is not None and lower_bound <= market_cap <= upper_bound:
                stocks_in_range.append({
                    "Symbol": symbol,
                    "Value": round(market_cap, 0)
                })

    elif(option == 4):
        for symbol in nifty_50_stocks:
            data2 = yf.Ticker(symbol+".ns").info
            om = data2.get('operatingMargins', 'Not available')*100
            if om is not None and lower_bound <= om <= upper_bound:
                stocks_in_range.append({
                    "Symbol": symbol,
                    "Value": round(om, 2)
                })

    return stocks_in_range

# Add a new route to handle AJAX request for filtered stocks
@app.route('/filter_stocks', methods=['POST'])
def filter_stocks():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])

        if request.method == 'POST':
            lower_bound = float(request.form.get('lowerBound'))
            upper_bound = float(request.form.get('upperBound'))
            option = float(request.form.get('option'))
            filtered_stocks = get_stocks_in_range(lower_bound, upper_bound, option)
            return jsonify(filtered_stocks)

    return redirect(url_for('dashboard'))

#xxxxxxxxxxxxxxxxxxxx-------------------------------
#Fundamentals

@app.route('/get_stock_info/<symbol>')
def get_stock_info(symbol):
    try:
        data = yf.Ticker(symbol+".ns").info
        stock_info = {
            "Symbol": symbol,
            "MarketCap (in cr.)": data.get('marketCap', 'Not available'),
            "P/E Ratio": data.get('trailingPE', 'Not available'),
            "PEG Ratio": data.get('pegRatio', 'Not available'),
            "Institutional holding": data.get('heldPercentInstitutions', 'Not available'),
            "Promoter holding": data.get('heldPercentInsiders', 'Not available'),
            "EPS": data.get('trailingEps', 'Not available'),
            "Dividend Yield": data.get('dividendYield', 'Not available'),
            "Operating Margins": data.get('operatingMargins', 'Not available'),
            "Industry": data.get('industry', 'Not available'),
            "Sector": data.get('sector', 'Not available'),
            "Business Summary": data.get('longBusinessSummary', 'Not available')
        }
        if (stock_info['P/E Ratio'] != 'Not available'):
            stock_info['P/E Ratio'] = str(round(stock_info['P/E Ratio'],2))
        if (stock_info['PEG Ratio'] != 'Not available'):
            stock_info['PEG Ratio'] = str(round(stock_info['PEG Ratio'],2))
        if (stock_info['Institutional holding'] != 'Not available'):
            stock_info['Institutional holding'] = str(round(stock_info['Institutional holding']*100,2))+'%'
        if (stock_info['Promoter holding'] != 'Not available'):
            stock_info['Promoter holding'] = str(round(stock_info['Promoter holding']*100,2))+'%'
        if (stock_info['MarketCap (in cr.)'] != 'Not available'):
            stock_info['MarketCap (in cr.)'] = round(stock_info['MarketCap (in cr.)']/10**7,0)
        if (stock_info['Dividend Yield'] != 'Not available'):
            stock_info['Dividend Yield'] = str(round(stock_info['Dividend Yield']*100,2))+'%'
        if (stock_info['Operating Margins'] != 'Not available'):
            stock_info['Operating Margins'] = str(round(stock_info['Operating Margins']*100,2))+'%'
        return jsonify(stock_info)

    except yf.Ticker.TickerError as e:
        return jsonify({"error": str(e)})


@app.route('/fundamentals')
def fundamentals():
    return render_template('fundamentals.html')

#xxxxxxxxxxxxxxxxxxxx-------------------------------
#Portfolio

@app.route('/portfolio')
def portfolio():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        portfolio_entries = Portfolio.query.filter_by(user_id=user.id).all()
        today_date = date.today().strftime("%Y-%m-%d")

        for entry in portfolio_entries:
            entry.ltp = get_ltp(entry.symbol)
            if entry.ltp is not None:
                entry.current_value = entry.ltp * entry.quantity
                entry.profit_loss = round((entry.ltp - entry.purchase_price) * entry.quantity,2)
                entry.profit_loss_percentage = round(((entry.ltp - entry.purchase_price) / entry.purchase_price) * 100,2)
            else:
                entry.current_value = None
                entry.profit_loss = None
                entry.profit_loss_percentage = None

        total_invested_amount = sum(entry.purchase_price * entry.quantity for entry in portfolio_entries)
        total_current_value = sum(entry.ltp * entry.quantity for entry in portfolio_entries if entry.ltp is not None)
        total_unrealized_return = total_current_value - total_invested_amount

        return render_template('portfolio.html', username=session['username'], portfolio=portfolio_entries,
                               total_invested_amount=total_invested_amount, total_current_value=total_current_value,
                               total_unrealized_return=total_unrealized_return, today_date=today_date)


        return render_template('portfolio.html', username=session['username'], portfolio=portfolio)

    return redirect(url_for('index'))

@app.route('/update_portfolio', methods=['POST'])
def update_portfolio():
    if 'user_id' in session:
        user_id = session['user_id']
        symbol = request.form.get('symbol')
        operation = request.form.get('operation')
        date_str = request.form.get('date')
        price = float(request.form.get('price'))
        quantity = int(request.form.get('quantity'))

        purchase_date = datetime.strptime(date_str, '%Y-%m-%d').date()

        existing_entry = Portfolio.query.filter_by(user_id=user_id, symbol=symbol).first()

        if operation == 'add':
            if existing_entry:
                # Calculate the new average price and update the quantity
                total_quantity = existing_entry.quantity + quantity
                total_value = (existing_entry.purchase_price * existing_entry.quantity) + (price * quantity)
                new_average_price = total_value / total_quantity

                # Update the existing entry
                existing_entry.purchase_date = purchase_date
                existing_entry.quantity = total_quantity
                existing_entry.purchase_price = new_average_price
            else:
                # If the stock is not in the portfolio, create a new entry
                new_entry = Portfolio(
                    user_id=user_id,
                    symbol=symbol,
                    purchase_date=purchase_date,
                    quantity=quantity,
                    purchase_price=price,
                )
                db.session.add(new_entry)

        elif operation == 'sell':
            if existing_entry and existing_entry.quantity >= quantity:
                new_quantity = existing_entry.quantity - quantity
                existing_entry.quantity = new_quantity
                if new_quantity == 0:
                    db.session.delete(existing_entry)
            else:
                flash("Insufficient quantity to sell")

        db.session.commit()

    return redirect(url_for('portfolio'))

#xxxxxxxxxxxxxxxxxxxx-------------------------------
#View_Chart

@app.route('/view_chart/<symbol>', methods=['GET', 'POST'])
def view_chart(symbol):
    return render_template('view_chart.html', symbol=symbol)

@app.route('/get_stock_data/<symbol>/<timeframe>', methods=['GET'])
def get_stock_data(symbol, timeframe):
    csv_filename = None
    if timeframe == 'daily':
        csv_filename = stock_data(symbol, interval='1d')
    elif timeframe == 'weekly':
        csv_filename = stock_data(symbol, interval='1wk')
    elif timeframe == 'monthly':
        csv_filename = stock_data(symbol, interval='1mo')

    with open(csv_filename, 'r') as csv_file:
        csv_data = csv_file.read()

    return jsonify({'symbol': symbol, 'csv_data': csv_data})

#xxxxxxxxx------------------------------------------------------------------------
#COMPARISON CHARTS

def stock_data_comp(symbol):
    date_today = date.today()
    date_start = date_today.replace(year=date_today.year - 1)
    date_today = date_today.strftime("%Y-%m-%d")
    date_start = date_start.strftime("%Y-%m-%d")

    data = yf.download(symbol+".ns", start=date_start, end=date_today)
    df = data.reset_index()
    
    stock_data = df[['Date', 'Close']]
    stock_data['Close'] = round(100* stock_data['Close'] / stock_data.loc[0, 'Close'],2)
    return stock_data.to_csv(index=False)

#This is the page where user can select stocks to generate their comparison charts
@app.route('/compare_charts', methods=['GET', 'POST'])
def compare_charts():
    if 'user_id' in session:
        return render_template('compare_charts.html')

    return redirect(url_for('index'))

#This is an intermediate route which takes a list of stocks as input from /compare_charts and stores them in the session data
@app.route('/get_comp_data', methods=['POST'])
def get_comp_data():
    selected_symbols = request.json.get('symbols', [])
    print(selected_symbols)
    session['comparison'] = selected_symbols
    return jsonify({})

#This route generates the comparison chart for the list of stocks stored if the session data
@app.route('/comparison')
def comparison():
    stock_data_list = []
    for symbol in session['comparison']:
        stock_data_list.append({'symbol': symbol, 'csv_data': stock_data_comp(symbol)})
    return render_template('comparison.html', data_list=stock_data_list)

#xxxxxxxxx------------------------------------------------------------------------

if __name__ == '__main__':
    
    app.run(debug=True)
    
