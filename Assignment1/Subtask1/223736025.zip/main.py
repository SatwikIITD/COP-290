import sys
import time
from datetime import date, timedelta
from jugaad_data.nse import stock_df
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import os
import matplotlib.pyplot as plt
import numpy as np

def func(stock_symbol, no_of_years):
    start = date.today() - timedelta(days=365 * no_of_years)
    df = stock_df(symbol=stock_symbol, from_date=start, to_date=date.today(), series="EQ")

    # Selecting specific columns
    columns = ['DATE', 'OPEN', 'CLOSE', 'HIGH', 'LOW', 'LTP', 'VOLUME', 'VALUE', 'NO OF TRADES']
    df = df[columns]
    
    # CSV file
    path = stock_symbol+'.csv'

    # Benchmark writing CSV file
    start_time = time.time()
    df.to_csv(path, index=False)
    csv_time = time.time() - start_time
    csv_size = os.path.getsize(path)

    # Binary file
    path = stock_symbol+'.bin'

    # Benchmark writing binary file
    start_time = time.time()
    df.to_pickle(path)
    binary_time = time.time() - start_time
    binary_size = os.path.getsize(path)

    # Parquet file
    path = stock_symbol+'.parquet'

    # Benchmark writing Parquet file
    start_time = time.time()
    table = pa.Table.from_pandas(df)
    pq.write_table(table, path)
    parquet_time = time.time() - start_time
    parquet_size = os.path.getsize(path)

    # Text file
    path = stock_symbol+'.txt'

    # Benchmark writing Text file
    start_time = time.time()
    with open(path, 'w') as file:
        Head = '\t'.join(df.columns) + '\n'
        file.write(Head)

        for _, row in df.iterrows():
            # Remove the time part from the date
            row['DATE'] = row['DATE'].strftime('%Y-%m-%d')
            
            txt_str = '\t'.join(map(str, row.values)) + '\n'
            file.write(txt_str)

    txt_time = time.time() - start_time
    txt_size = os.path.getsize(path)

    # Print benchmark results
    print(f"CSV: Time = {csv_time:.4f} seconds, Size = {csv_size} bytes")
    print(f"Binary: Time = {binary_time:.4f} seconds, Size = {binary_size} bytes")
    print(f"Parquet: Time = {parquet_time:.4f} seconds, Size = {parquet_size} bytes")
    print(f"Text: Time = {txt_time:.4f} seconds, Size = {txt_size} bytes")

    # Generate a double bar graph
    types = ['CSV', 'Binary', 'Parquet', 'Text']
    times = [csv_time, binary_time, parquet_time, txt_time]
    sizes = [csv_size, binary_size, parquet_size, txt_size]

    fig, plot1 = plt.subplots(figsize=(10, 6))

    bar_width = 0.35
    index = np.arange(len(types))

    bars1 = plot1.bar(index, times, bar_width, label='Time', color='tab:blue')
    plot1.set_xlabel('File Format')
    plot1.set_ylabel('Time (seconds)', color='tab:blue')
    plot1.set_xticks(index)
    plot1.set_xticklabels(types)
    plot1.tick_params(axis='y', labelcolor='tab:blue')

    plot2 = plot1.twinx()
    bars2 = plot2.bar(index + bar_width, sizes, bar_width, label='Size', color='tab:red')
    plot2.set_ylabel('File Size (bytes)', color='tab:red')
    plot2.set_xticks(index + bar_width / 2)
    plot2.set_xticklabels(types)
    plot2.tick_params(axis='y', labelcolor='tab:red')

    # Add legends for each axis
    plot1.legend(loc='upper left', bbox_to_anchor=(1.15, 1.15))
    plot2.legend(loc='upper left', bbox_to_anchor=(1.15, 1))

    plt.title('Time and Size for Different File Formats')
    plt.tight_layout()
    plt.savefig(stock_symbol+'.png')
    plt.show()

# Main program
if __name__ == "__main__":
    
    stock_symbol = sys.argv[1]
    no_of_years = int(sys.argv[2])

    func(stock_symbol, no_of_years)
