#include <bits/stdc++.h>
using namespace std;
typedef vector<vector<double>> Matrix;
typedef vector<double> Vector;

// Function to perform matrix transposition
Matrix transpose(const Matrix& A) {
    int rows = A.size();
    int cols = A[0].size();
    Matrix result(cols, Vector(rows));
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            result[j][i] = A[i][j];
        }
    }
    return result;
}

// Function to perform matrix multiplication
Matrix multiply(const Matrix& A, const Matrix& B) {
    int rows_A = A.size();
    int cols_A = A[0].size();
    int rows_B = B.size();
    int cols_B = B[0].size();
    Matrix result(rows_A, Vector(cols_B));
    for (int i = 0; i < rows_A; ++i) {
        for (int j = 0; j < cols_B; ++j) {
            result[i][j] = 0;
            for (int k = 0; k < cols_A; ++k) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return result;
}

Matrix inverse(const Matrix& arr){
    int n=arr.size();
    vector<vector<double>> aug(n, vector<double>(2*n));
    for(int i=0;i<n;i++){
        aug[i][i+n]=1;
        for(int j=0;j<n;j++){
            aug[i][j]=arr[i][j];
        }
    }
    for(int i=0;i<n;i++){
        double d=aug[i][i];
        if(d==0) d=0.01;
        for(int j=0;j<2*n;j++) aug[i][j]/=d;
        for(int k=0;k<n;k++){
            if(k!= i){
                double f=aug[k][i];
                for(int j=0;j<2*n;j++){
                    aug[k][j]-=f*aug[i][j];
                }
            }
        }
    }
    vector<vector<double>> inv(n, vector<double>(n));
    for (int i=0;i<n;i++) {
        for (int j=0;j<n;j++) {
            inv[i][j] = aug[i][j + n];
        }
    }
    return inv;
}

// Function to perform vector multiplication
Vector multiply(const Matrix& A, const Vector& v) {
    int rows_A = A.size();
    int cols_A = A[0].size();
    int size_v = v.size();
    Vector result(rows_A);
    for (int i = 0; i < rows_A; ++i) {
        result[i] = 0;
        for (int j = 0; j < cols_A; ++j) {
            result[i] += A[i][j] * v[j];
        }
    }
    return result;
}

// Function to compute beta parameters using normal equation
Vector computeBetaParameters(const Matrix& X, const Vector& y) {
    // Compute beta parameters using normal equation: β = (X^T * X)^-1 * X^T * y
    Matrix X_transpose = transpose(X);
    Matrix X_transpose_X = multiply(X_transpose, X);
    Matrix inverse_X_transpose_X = inverse(X_transpose_X);
    Vector X_transpose_y = multiply(X_transpose, y);
    auto final = multiply(inverse_X_transpose_X, X_transpose_y);
    return final;
}

class LinearRegressionStrategy : public Strategy {
private:
    int x; 
    double p; 
    string train_start_date;
    string train_end_date;
    Vector beta; 

  
    double predictPrice(const StockData& data, int i) {

        double beta0 = beta[0];
        double beta1 = beta[1];
        double beta2 = beta[2];
        double beta3 = beta[3];
        double beta4 = beta[4];
        double beta5 = beta[5];
        double beta6 = beta[6];
        double beta7 = beta[7];

        
        double predicted_price = beta0 + beta1 * data.close[i+1] + beta2 * data.open[i+1]
                                + beta3 * data.vwap[i+1] + beta4 * data.low[i+1]
                                + beta5 * data.high[i+1] + beta6 * data.no_trades[i+1]
                                + beta7 * data.open[i];
        return predicted_price;
    }

public:
    LinearRegressionStrategy(const string& symbol, const string& start_date, const string& end_date, int x, int p, const string& train_start_date, const string& train_end_date)
        : Strategy(symbol, start_date, end_date),
          x(x), p(p), train_start_date(start_date), train_end_date(end_date) {
    }

    void implementStrategy(const StockData& stockData) override {
        // Compute beta parameters using training data
        cout<<"Start implementation"<<endl;
        int startidx = stockData.startidx;
        string strategy = "LINEAR_REGRESSION";
        StockData trainData(strategy, symbol, -1);
        Matrix A(trainData.date.size()-1, vector<double>(8));
        Vector y(trainData.date.size()-1);
        vector<vector<double>> ydata;
      
        for (size_t i = 0; i < trainData.date.size()-1; ++i) {
            A[i][0] = 1; // Intercept term
            A[i][1] = trainData.close[i+1];
            A[i][2] = trainData.open[i+1];
            A[i][3] = trainData.vwap[i+1];
            A[i][4] = trainData.low[i+1];
            A[i][5] = trainData.high[i+1];
            A[i][6] = trainData.no_trades[i+1];
            A[i][7] = trainData.open[i];
            y[i] = trainData.close[i];
        }
    
        int quantity=1;
        int position=0;
        double CashInHand=0;
        
        int i=0,j=A.size()-1;
        while(i<j){
            for(int k=0;k<8;k++){
                auto temp=A[i][k];
                A[i][k]=A[j][k];
                A[j][k]=temp;
            }
            i++;
            j--;
        }
        reverse(y.begin(),y.end());

        beta = computeBetaParameters(A, y);
        
        
        cout<<"Beta parameters are:"<<endl;
        for(int i=0;i<beta.size();i++){
            cout<<beta[i]<<" ";
        }
        cout<<endl;

        for (int i=startidx;i>=0;i--) {
            double predicted_price = predictPrice(stockData,i);
            // Compare predicted price with actual price and make buy/sell decision
            double price_difference = predicted_price - stockData.close[i];
            if (price_difference >= (p/100) * stockData.close[i] && position<x) {
                // Buy the stock
                orderStats.emplace_back(stockData.date[i],"BUY",quantity,stockData.close[i]);
                position++;
                CashInHand -= quantity * stockData.close[i];
            } else if (-1*price_difference >= (p/100) * stockData.close[i] && position>-x) {
                // Sell the stock
                orderStats.emplace_back(stockData.date[i],"SELL",quantity,stockData.close[i]);
                position--;
                CashInHand += quantity * stockData.close[i];
            }
            // Calculate cashflow and write daily cashflow
            // Cashflow calculation logic here
            dailyCashflows.emplace_back(stockData.date[i], CashInHand);
        }

        // SQUARE-OFF
        CashInHand += position * stockData.close[0];
        finalpnl = CashInHand;
        cout << "DONE" << endl;
        return;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing Basic Strategy" << endl;
        implementStrategy(stockData);
        writeOrderStatistics(orderStats);
        writeDailyCashflow(dailyCashflows);
        writeFinalPnL(finalpnl);
    }
};
