import sys
from datetime import datetime, timedelta
from jugaad_data.nse import stock_df

def get_data(symbol, from_date, to_date, series):
    while True:
        try:
            complete_df = stock_df(symbol=symbol, from_date=from_date, to_date=to_date, series=series)
        except:
            continue
        else:
            break
    return complete_df

def stock_data(strategy, symbol, start_date, end_date, n, symbol2 = None, start_date_train = None, end_date_train = None):
    
    start_date_dt = datetime.strptime(start_date, '%d/%m/%Y')    
    end_date_dt = datetime.strptime(end_date, '%d/%m/%Y')
    startidx = 0
    if (strategy == "PAIRS"):
        complete_df = get_data(symbol=symbol, from_date=start_date_dt, to_date=end_date_dt, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        startidx = len(df)-1
        print(startidx)

        csv_filename = f"{symbol}.csv"
        df.to_csv(csv_filename, index=False)


        extra_days = (n//7+3)*3+n
        data_start_date = start_date_dt - timedelta(days=extra_days)
        data_end_date = start_date_dt - timedelta(days=1)
        complete_df = get_data(symbol=symbol, from_date=data_start_date, to_date=data_end_date, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        df.head(n).to_csv(csv_filename, mode='a', index=False, header=False)

        complete_df = get_data(symbol=symbol2, from_date=start_date_dt, to_date=end_date_dt, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        csv_filename = f"{symbol2}.csv"
        df.to_csv(csv_filename, index=False)

        extra_days = (n//7+3)*3+n
        data_start_date = start_date_dt - timedelta(days=extra_days)
        data_end_date = start_date_dt - timedelta(days=1)
        complete_df = get_data(symbol=symbol2, from_date=data_start_date, to_date=data_end_date, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        df.head(n).to_csv(csv_filename, mode='a', index=False, header=False)
    
    elif strategy == "LINEAR_REGRESSION":
        complete_df = get_data(symbol=symbol, from_date=start_date_dt, to_date=end_date_dt, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        startidx = len(df)-1
        print(startidx)

        csv_filename = f"{symbol}.csv"
        df.to_csv(csv_filename, index=False)

        extra_days = 5
        data_start_date = start_date_dt - timedelta(days=extra_days)
        data_end_date = start_date_dt - timedelta(days=1)
        complete_df = get_data(symbol=symbol, from_date=data_start_date, to_date=data_end_date, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        df.head(1).to_csv(csv_filename, mode='a', index=False, header=False)

        start_date_dt = datetime.strptime(start_date_train, '%d/%m/%Y')    
        end_date_dt = datetime.strptime(end_date_train, '%d/%m/%Y')

        complete_df = get_data(symbol=symbol, from_date=start_date_dt, to_date=end_date_dt, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        csv_filename = f"{symbol}_train.csv"
        df.to_csv(csv_filename, index=False)

        extra_days = 5
        data_start_date = start_date_dt - timedelta(days=extra_days)
        data_end_date = start_date_dt - timedelta(days=1)
        complete_df = get_data(symbol=symbol, from_date=data_start_date, to_date=data_end_date, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        df.head(1).to_csv(csv_filename, mode='a', index=False, header=False)

    elif strategy == "BEST_OF_ALL":
        complete_df = get_data(symbol=symbol, from_date=start_date_dt, to_date=end_date_dt, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        startidx = len(df)-1
        print(startidx)

        csv_filename = f"{symbol}.csv"
        df.to_csv(csv_filename, index=False)

        extra_days = (n//7+3)*3+n
        data_start_date = start_date_dt - timedelta(days=extra_days)
        data_end_date = start_date_dt - timedelta(days=1)
        complete_df = get_data(symbol=symbol, from_date=data_start_date, to_date=data_end_date, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        df.head(n).to_csv(csv_filename, mode='a', index=False, header=False)

        start_date_dt = datetime.strptime(start_date_train, '%d/%m/%Y')    
        end_date_dt = datetime.strptime(end_date_train, '%d/%m/%Y')

        complete_df = get_data(symbol=symbol, from_date=start_date_dt, to_date=end_date_dt, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        csv_filename = f"{symbol}_train.csv"
        df.to_csv(csv_filename, index=False)

        extra_days = 5
        data_start_date = start_date_dt - timedelta(days=extra_days)
        data_end_date = start_date_dt - timedelta(days=1)
        complete_df = get_data(symbol=symbol, from_date=data_start_date, to_date=data_end_date, series="EQ")
        complete_df = complete_df.drop_duplicates()
        df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW', 'OPEN', 'VWAP', 'NO OF TRADES']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        df.head(1).to_csv(csv_filename, mode='a', index=False, header=False)


    else:
        complete_df = get_data(symbol=symbol, from_date=start_date_dt, to_date=end_date_dt, series="EQ")
        complete_df = complete_df.drop_duplicates()
        if strategy=='ADX':
            df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW']].copy()
        else:
            df = complete_df[['DATE', 'CLOSE']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        startidx = len(df)-1
        print(startidx)

        csv_filename = f"{symbol}.csv"
        df.to_csv(csv_filename, index=False)


        extra_days = (n//7+3)*3+n
        data_start_date = start_date_dt - timedelta(days=extra_days)
        #print(extra_days)
        #print(data_start_date)
        data_end_date = start_date_dt - timedelta(days=1)
        complete_df = get_data(symbol=symbol, from_date=data_start_date, to_date=data_end_date, series="EQ")
        complete_df = complete_df.drop_duplicates()
        if strategy=='ADX':
            df = complete_df[['DATE', 'CLOSE', 'HIGH', 'LOW']].copy()
        else:
            df = complete_df[['DATE', 'CLOSE']].copy()
        df['DATE'] = df['DATE'].dt.strftime('%d/%m/%Y')

        df.head(n).to_csv(csv_filename, mode='a', index=False, header=False)

    #print(f"Stock data saved")
    return startidx

def main():
    if len(sys.argv) < 2:
        print("Usage: python main.py --strategy=<strategy> --symbol=<symbol> --start_date=<start_date> --end_date=<end_date> [<additional_arguments>]")
        return

    strategy = None
    symbol = None
    symbol2 = None
    start_date = None
    end_date = None
    n = 50
    train_start_date = None
    train_end_date = None

    for arg in sys.argv[1:]:
        if arg.startswith("--strategy="):
            strategy = arg.split("=")[1]
        elif arg.startswith("--symbol="):
            symbol = arg.split("=")[1]
        elif arg.startswith("--symbol1="):
            symbol = arg.split("=")[1]
        elif arg.startswith("--symbol2="):
            symbol2 = arg.split("=")[1]
        elif arg.startswith("--start_date="):
            start_date = arg.split("=")[1]
        elif arg.startswith("--end_date="):
            end_date = arg.split("=")[1]
        elif arg.startswith("--n="):
            n = int(arg.split("=")[1])
        elif arg.startswith("--train_start_date="):
            train_start_date = arg.split("=")[1]
        elif arg.startswith("--train_end_date="):
            train_end_date = arg.split("=")[1]
    if strategy == "PAIRS":
        stock_data(strategy, symbol, start_date, end_date, n, symbol2)
    elif strategy == "LINEAR_REGRESSION":
        stock_data(strategy, symbol, start_date, end_date, n, start_date_train=train_start_date, end_date_train=train_end_date)
    elif strategy == "BEST_OF_ALL":
        train_start_date = start_date[:-4] + str(int(start_date[-4:])-1)
        train_end_date = end_date[:-4] + str(int(end_date[-4:])-1)
        stock_data(strategy, symbol, start_date, end_date, n, start_date_train=train_start_date, end_date_train=train_end_date)
    else:
        stock_data(strategy, symbol, start_date, end_date, n)

if __name__ == "__main__":
    main()
