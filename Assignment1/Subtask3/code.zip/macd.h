//macd.h
#ifndef MACD_STRATEGY_H
#define MACD_STRATEGY_H

#include "strategy.h"
#include "indicators.h"


void writeMACDtoCSV(const vector<string>& date, const vector<double>& macd) {
    // Open the CSV file for writing
    ofstream file("macd_data.csv");

    // Check if the file is opened successfully
    if (!file.is_open()) {
        cerr << "Error opening file for writing." << endl;
        return;
    }

    // Write column headers
    file << "Date, MACD Value" << endl;

    // Write data to the file in reverse order of dates
    for (int i = date.size() - 1; i >= 0; --i) {
        file << date[i] << "," << macd[i] << endl;
    }

    // Close the file
    file.close();
}

class MACDStrategy : public Strategy {
private:
    int x;

public:
    MACDStrategy(const string& symbol, const string& start_date, const string& end_date, int x)
        : Strategy(symbol, start_date, end_date), x(x) {}

    void implementStrategy(const StockData& stockData) override {
        int startidx = stockData.startidx;
        double CashInHand = 0;
        int position = 0;
        int quantity = 1;

        MACDIndicator macdIndicator;
        macdIndicator.calculate(stockData);
        const vector<double>& macd = macdIndicator.getMACD();
        const vector<double>& signal = macdIndicator.getSignalLine();

         writeMACDtoCSV(stockData.date, macd);


        cout << x << endl;
        for (int i = startidx; i >=0; i--){
            cout << stockData.date[i] << ' ' << stockData.close[i] << ' ' << macd[i]  << ' ' << signal[i]<< endl;
        }

        for (int day = startidx; day >= 0; day--) {
            if (macd[day] > signal[day] && position < x) { // Buy condition
                orderStats.emplace_back(stockData.date[day], "BUY", quantity, stockData.close[day]);
                position++;
                CashInHand -= quantity * stockData.close[day];
            }
            else if (macd[day] < signal[day] && position > -x) { // Sell condition
                orderStats.emplace_back(stockData.date[day], "SELL", quantity, stockData.close[day]);
                position--;
                CashInHand += quantity * stockData.close[day];
            }
            dailyCashflows.emplace_back(stockData.date[day], CashInHand);
        }

        // Square off
        CashInHand += position * stockData.close[0];
        finalpnl = CashInHand;
        cout << "DONE" << endl;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing MACD Strategy" << endl;
        implementStrategy(stockData);
        writeOrderStatistics(orderStats);
        writeDailyCashflow(dailyCashflows);
        writeFinalPnL(finalpnl);
    }
};

#endif // MACD_STRATEGY_H
