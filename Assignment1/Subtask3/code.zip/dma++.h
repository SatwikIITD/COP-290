//dma++.h
#ifndef IMPROVED_DMA_STRATEGY_H
#define IMPROVED_DMA_STRATEGY_H

#include <queue>
#include "strategy.h"
#include "indicators.h"

class ImprovedDMAStrategy : public Strategy {
private:
    int x;
    double p;
    int n;
    int maxHoldDays;
    double c1;
    double c2;

public:
    ImprovedDMAStrategy(const string& symbol, const string& start_date, const string& end_date, int x, double p, int n, int maxHoldDays, double c1, double c2)
        : Strategy(symbol, start_date, end_date), x(x), p(p), n(n), maxHoldDays(maxHoldDays), c1(c1), c2(c2) {}

    void implementStrategy(const StockData& stockData) override {
        cout << "I am here" << endl;
        int startidx = stockData.startidx;
        cout << startidx << endl;
        cout << n << endl;
        double CashInHand = 0;
        int position = 0;
        int quantity = 1;

        AMAIndicator amaIndicator(n, c1, c2); // Creating an instance of AMAIndicator
        amaIndicator.calculate(stockData);
        const vector<double>& ama = amaIndicator.getAMA();

        for (int i = startidx; i >=0; i--){
            cout << stockData.date[i] << ' ' << stockData.close[i] << ' ' << ama[i] << ' ' << ama[i]*(1+p/100) << endl;
        }

        // Auxiliary variables for stop-loss implementation
        int open_dir=0;
        queue<int> open_pos;

        for (int day = startidx; day >= 0; day--) {
            // Buy condition
            if (stockData.close[day] >= (1 + p / 100) * ama[day] && position < x) {
                orderStats.emplace_back(stockData.date[day], "BUY", quantity, stockData.close[day]);
                position += quantity;
                CashInHand -= quantity * stockData.close[day];
                if (open_dir==-1){
                    open_pos.pop();
                    if (open_pos.empty()) open_dir=0;
                }
                else{
                    if (open_dir==0) open_dir=1;
                    open_pos.push(day);
                }
            }
            // Sell condition
            else if (stockData.close[day] <= (1 - p / 100) * ama[day] && position > -x) {
                orderStats.emplace_back(stockData.date[day], "SELL", quantity, stockData.close[day]);
                position -= quantity;
                CashInHand += quantity * stockData.close[day];
                if (open_dir==1){
                    open_pos.pop();
                    if (open_pos.empty()) open_dir=0;
                }
                else{
                    if (open_dir==0) open_dir=-1;
                    open_pos.push(day);
                }
            }

            // Stop-loss implementation
            if (open_pos.front()-day == maxHoldDays) {
                if (open_dir == 1){
                    cout << "check1 " << stockData.date[day] << ' ' << orderStats.back().date << endl;
                    if (stockData.close[day] >= (1 + p / 100) * ama[day] && position == x){

                    }
                    else{
                        if (orderStats.back().date == stockData.date[day] and orderStats.back().direction=="SELL"){
                            
                        }
                        else{
                            if (orderStats.back().date == stockData.date[day]){
                                orderStats.pop_back();
                            }
                            else orderStats.emplace_back(stockData.date[day], "SELL", quantity, stockData.close[day]);

                            position -= quantity;
                            CashInHand += quantity * stockData.close[day];
                            open_pos.pop();
                            if (open_pos.empty()) open_dir=0;
                        }
                    }
                }
                else if (open_dir == -1) { // If we have short-sold shares, buy them back
                    cout << "check2 " << stockData.date[day] << ' ' << orderStats.back().date << endl;
                    if (stockData.close[day] <= (1 - p / 100) * ama[day] && position == -x){

                    }
                    else{
                        if (orderStats.back().date == stockData.date[day] and orderStats.back().direction=="BUY"){
                            
                        }
                        else{
                            if (orderStats.back().date == stockData.date[day]){
                                orderStats.pop_back();
                            }
                            else orderStats.emplace_back(stockData.date[day], "BUY", quantity, stockData.close[day]);
                            position += quantity;
                            CashInHand -= quantity * stockData.close[day];
                            open_pos.pop();
                            if (open_pos.empty()) open_dir=0;
                        }
                    }
                }
            }
            dailyCashflows.emplace_back(stockData.date[day], CashInHand);
        }

        // Square off remaining positions
        CashInHand += position * stockData.close[0];
        finalpnl = CashInHand;
        cout << "DONE" << endl;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing Improved DMA Strategy" << endl;
        implementStrategy(stockData);
        writeOrderStatistics(orderStats);
        writeDailyCashflow(dailyCashflows);
        writeFinalPnL(finalpnl);
    }
};

#endif // IMPROVED_DMA_STRATEGY_H
