//rsi.h
#ifndef RSI_STRATEGY_H
#define RSI_STRATEGY_H

#include "strategy.h"
#include "indicators.h"

void writeRSItoCSV(const vector<string>& date, const vector<double>& rsi) {
    // Open the CSV file for writing
    ofstream file("rsi_data.csv");

    // Check if the file is opened successfully
    if (!file.is_open()) {
        cerr << "Error opening file for writing." << endl;
        return;
    }

    // Write column headers
    file << "Date, RSI Value" << endl;

    // Write data to the file in reverse order of dates
    for (int i = date.size() - 1; i >= 0; --i) {
        file << date[i] << "," << rsi[i] << endl;
    }

    // Close the file
    file.close();
}

class RSIStrategy : public Strategy {
private:
    int n;
    int x;
    double oversold_threshold;
    double overbought_threshold;

public:
    RSIStrategy(const string& symbol, const string& start_date, const string& end_date, int n, int x, double oversold_threshold, double overbought_threshold)
        : Strategy(symbol, start_date, end_date), n(n), x(x), oversold_threshold(oversold_threshold), overbought_threshold(overbought_threshold) {}

    void implementStrategy(const StockData& stockData) override {
        int startidx = stockData.startidx;
        double CashInHand = 0;
        int position = 0;
        int quantity = 1;

        RSIIndicator rsiIndicator(n); // Assuming the period for RSI calculation is 14 days
        rsiIndicator.calculate(stockData);
        const vector<double>& rsi = rsiIndicator.getRSI();

        writeRSItoCSV(stockData.date, rsi);

        //cout << x  << ' '<< oversold_threshold << ' ' << overbought_threshold << ' ' << startidx << endl;
        // for (int i = startidx; i >=0; i--){
        //     cout << stockData.date[i] << ' ' << stockData.close[i] << ' ' << rsi[i] << endl;
        // }

        for (int day = startidx; day >= 0; day--) {
            if (rsi[day] < oversold_threshold && position < x) { // Buy condition
                orderStats.emplace_back(stockData.date[day], "BUY", quantity, stockData.close[day]);
                position++;
                CashInHand -= quantity * stockData.close[day];
                cout << "BUY " << stockData.date[day] << ' ' << stockData.close[day] << ' ' << rsi[day] << endl;
            }
            else if (rsi[day] > overbought_threshold && position > -x) { // Sell condition
                orderStats.emplace_back(stockData.date[day], "SELL", quantity, stockData.close[day]);
                position--;
                CashInHand += quantity * stockData.close[day];
                cout << "SELL " << stockData.date[day] << ' ' << stockData.close[day] << ' ' << rsi[day] << endl;
            }
            dailyCashflows.emplace_back(stockData.date[day], CashInHand);
        }

        // Square off
        CashInHand += position * stockData.close[0];
        finalpnl = CashInHand;
        cout << "DONE" << endl;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing RSI Strategy" << endl;
        implementStrategy(stockData);
        writeOrderStatistics(orderStats);
        writeDailyCashflow(dailyCashflows);
        writeFinalPnL(finalpnl);
    }
};

#endif // RSI_STRATEGY_H
