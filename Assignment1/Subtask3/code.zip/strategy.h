
#ifndef STRATEGY_H
#define STRATEGY_H
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

struct OrderStatistics {
    string date;
    string direction;
    int quantity;
    double price;

    OrderStatistics(const string& date, const string& direction, int quantity, double price)
        : date(date), direction(direction), quantity(quantity), price(price) {}
};

struct DailyCashFlow {
    string date;
    double cashflow;

    DailyCashFlow(const string& date, double cashflow)
        : date(date), cashflow(cashflow) {}
};

class StockData {
public:
    int startidx;
    vector<string> date;
    vector<double> close;
    vector<double> high;
    vector<double> low;
    vector<double> open;
    vector<double> vwap;
    vector<long long> no_trades;

    StockData(const string& strategy="", const string& symbol="", int index=-2){
        startidx = index;
        date.clear();
        close.clear();
        high.clear();
        low.clear();
        open.clear();
        vwap.clear();
        no_trades.clear();
        cout << "yes" << endl;
        if (index==-1){
            readStockData(strategy, symbol+"_train.csv");
        }
        else if(index==-2){
            
        }
        else{
            readStockData(strategy, symbol+".csv");
        }
        cout << "no" << endl;
        
    }

    void readStockData(const string& strategy, const string& filename){
        ifstream file(filename);

        if (!file.is_open()) {
            cerr << "Error opening file." << endl;
            return;
        }

        string line;
        getline(file, line); //To ignore the first row
        string datet, closet, hight, opent, lowt, vwapt, no_tradest;
        
        if (strategy == "BASIC" or strategy == "DMA" or strategy == "DMA++" or strategy == "MACD" or strategy == "RSI" or strategy == "PAIRS"){
            while (getline(file, line)) {
                stringstream ss(line);
                getline(ss, datet, ',');
                getline(ss, closet);
                date.push_back(datet);
                close.push_back(stod(closet));
            }
        }
        else if (strategy == "ADX"){
            while (getline(file, line)) {
                stringstream ss(line);
                getline(ss, datet, ',');
                getline(ss, closet, ',');
                getline(ss, hight, ',');
                getline(ss, lowt);
                date.push_back(datet);
                close.push_back(stod(closet));
                high.push_back(stod(hight));
                low.push_back(stod(lowt));
            }
        }
        else if (strategy == "LINEAR_REGRESSION" or strategy == "BEST_OF_ALL"){
            while (getline(file, line)) {
                stringstream ss(line);
                getline(ss, datet, ',');
                getline(ss, closet, ',');
                getline(ss, hight, ',');
                getline(ss, lowt, ',');
                getline(ss, opent, ',');
                getline(ss, vwapt, ',');
                getline(ss, no_tradest);
                date.push_back(datet);
                close.push_back(stod(closet));
                high.push_back(stod(hight));
                low.push_back(stod(lowt));
                open.push_back(stod(opent));
                vwap.push_back(stod(vwapt));
                no_trades.push_back(stoll(no_tradest));
            }
        }

        file.close();
        return;
    }
};

class Strategy {
public:
    string symbol;
    string start_date;
    string end_date;
    double finalpnl;
    vector<OrderStatistics> orderStats;
    vector<DailyCashFlow> dailyCashflows; 
    // Method to write order statistics
    void writeOrderStatistics(const vector<OrderStatistics>& orders, const string& filename = "order_statistics.csv") {
        ofstream outFile(filename, ios::app);
        outFile << "Date" << "," << "Order_dir" << "," << "Quantity" << "," << "Price" << endl;
        if (outFile.is_open()) {
            for (const auto& order : orders) {
                outFile << order.date << "," << order.direction << "," << order.quantity << "," << order.price << endl;
            }
            outFile.close();
        } else {
            cerr << "Error opening file for writing order statistics." << endl;
        }
    }

    // Method to write daily cashflow
    void writeDailyCashflow(const vector<DailyCashFlow>& cashflows, const string& filename = "daily_cashflow.csv") {
        ofstream outFile(filename, ios::app);
        outFile << "Date" << "," << "Cashflow" << endl;
        if (outFile.is_open()) {
            for (const auto& cash : cashflows) {
                outFile << cash.date << "," << cash.cashflow << endl;
            }
            outFile.close();
        } else {
            cerr << "Error opening file for writing daily cash flow." << endl;
        }
    }

    // Method to write final PnL
    void writeFinalPnL(double pnl, const string& filename = "final_pnl.txt") {
        ofstream outFile(filename);
        if (outFile.is_open()){
            outFile << pnl;
            outFile.close();
        }
        else{
            cerr << "Error opening file for writing final PnL." << endl;
        }
    }

    // Abstract method for strategy-specific logic
    virtual void implementStrategy(const StockData& stockData) = 0;


    Strategy(const string& symbol, const string& start_date, const string& end_date, 
                const string& cashflow_filename = "daily_cashflow.csv", 
                const string& order_filename = "order_statistics.csv",
                const string& pnl_filename = "final_pnl.txt")
        : symbol(symbol), start_date(start_date), end_date(end_date){
        
        
        // Delete the output files (if they exist)
        remove(cashflow_filename.c_str());
        remove(order_filename.c_str());
        remove(pnl_filename.c_str());
    }

    virtual void execute(const StockData& stockData) = 0;
};

#endif // STRATEGY_H
