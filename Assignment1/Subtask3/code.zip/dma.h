
#ifndef DMATREND_H
#define DMATREND_H

#include "strategy.h"
#include "indicators.h"
#include <fstream> 
#include <iomanip> 
#include <sstream> 


class DMATrend : public Strategy {
private:
    int n;
    int x;
    double p;

public:
    DMATrend(const string& symbol, const string& start_date, const string& end_date, int n, int x, double p)
        : Strategy(symbol, start_date, end_date), n(n), x(x), p(p) {}

    void implementStrategy(const StockData& stockData) override {
        int startidx = stockData.startidx;
        cout << startidx << endl;
        double CashInHand = 0;
        int position = 0;
        int quantity = 1;

        DMAIndicator dmaIndicator(50); 
        dmaIndicator.calculate(stockData);
        const vector<double>& dma = dmaIndicator.getDMA();


       

        
        SDIndicator sdIndicator(50); 
        sdIndicator.calculate(stockData);
        const vector<double>& sd = sdIndicator.getSD();

        
        for (int day = startidx; day >= 0; day--){
            if (stockData.close[day] > dma[day] + p * sd[day] and position < x) {
                orderStats.emplace_back(stockData.date[day], "BUY", quantity, stockData.close[day]);
                position += quantity;
                CashInHand -= quantity * stockData.close[day];
            }
            else if (stockData.close[day] < dma[day] - p * sd[day] and position > -x) {
                orderStats.emplace_back(stockData.date[day], "SELL", quantity, stockData.close[day]);
                position -= quantity;
                CashInHand += quantity * stockData.close[day];
            }
            dailyCashflows.emplace_back(stockData.date[day], CashInHand);
        }

        CashInHand += position * stockData.close[0];
        finalpnl = CashInHand;
        cout << "DONE" << endl;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing DMA Trend Strategy" << endl;
        implementStrategy(stockData);
        writeOrderStatistics(orderStats);
        writeDailyCashflow(dailyCashflows);
        writeFinalPnL(finalpnl);
    }
};

#endif 
