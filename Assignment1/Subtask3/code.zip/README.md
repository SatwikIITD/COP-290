# Trading Strategies
This repository contains several trading strategies implemented in C++. Each strategy is described briefly below.

## Basic Strategies

### Momentum Based Strategies
- Description: These strategies rely on the momentum of the price movement to determine entry and exit points.
- Simple moving average crossover strategy.
- This strategy is most optimal for n = 4. 

### Trend Based Strategies

#### DMA (Dual Moving Average)
- Description: This strategy uses two moving averages to identify trends and generate trading signals.
- Golden cross (short-term MA crosses above long-term MA) and death cross (short-term MA crosses below long-term MA).
- This strategy is most optimal when p lies between 1 and 1.5.
- To make this strategy better, we exit the position when price exceeds DMA by 2 standard deviations.

<img src="dma_plot.png" alt="DMA Plot" width="500">

#### Improved DMA
- Description: An enhanced version of the DMA strategy with additional filters or optimizations.
- Incorporating volume or volatility filters to improve signal quality.
- This strtegy is better than DMA strategy in the sense that it cuts positions that are not creating profits in order to free capital to invest in profitable trades.

#### MACD (Moving Average Convergence Divergence)
- Description: This strategy uses the MACD indicator to identify trend changes and generate signals.
- Bullish signal when MACD line crosses above the signal line, and bearish signal when MACD line crosses below the signal line.

<img src="macd_plot.png" alt="MACD Plot" width="500">

#### RSI (Relative Strength Index)
- Description: This strategy uses the RSI indicator to identify overbought and oversold conditions.
- Buying when RSI is below a certain threshold (oversold) and selling when RSI is above a certain threshold (overbought).
- Profit is optimal around overbought threshold value of 80-85 and oversold threshold value of 15-20. As the overbought threshold increases beyond this value, the number of trades decreases. Similarly as the oversold threshold decreases, the number of trades decreases.

<img src="rsi_plot.png" alt="RSI Plot" width="500">

#### ADX (Average Directional Index)
- Description:  ADX is one of the best indicators we have coded so far.
- Buying when ADX is above a certain level, indicating a strong trend, and selling when ADX is below that level, indicating a weak trend.
- If we add the conditions of ADX to other strategies, then those strategies become better.

<img src="adx_plot.png" alt="ADX Plot" width="500">

## Advanced Strategies

### Linear Regression

- Description: In our linear regression implementation, we experimented with both solving the normal equations and employing gradient descent for parameter optimization. Through testing, we observed that the choice between these methods depends on factors like dataset size and problem complexity.
- Gradient descent tends to excel with large datasets or complex relationships, while solving the normal equations often performs better with smaller datasets or simpler problems. Therefore, the selection of optimization method should be based on careful consideration of these factors.


### Best of All Strategy
- Description: This strategy combines multiple individual strategies and compares their performance to determine the best strategy.
- Running all implemented strategies simultaneously using pthreads and evaluating their final PnL values to select the most profitable one.
- On running different strategies, we found that no one indicator is the best. Every indicator has its strengths in different ranges of time.

### Mean Reverting Pairs Strategy
- Description: This strategy identifies pairs of assets that tend to move together and takes advantage of temporary deviations from their historical relationship.
- Calculating the spread between two correlated assets and buying/selling when the spread exceeds a certain threshold, with a stop loss to limit losses.

## Usage
- Each strategy implementation can be found in its respective directory.
- Detailed instructions on running each strategy are provided in their respective README files.

## License
This project is licensed under the [MIT License](LICENSE).

## Acknowledgements
- Mention any libraries, datasets, or resources used in developing these strategies.
