#ifndef INDICATORS_H
#define INDICATORS_H

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cmath>
#include "strategy.h"

using namespace std;

// Base class for indicators
class Indicator {
public:
    virtual void calculate(const StockData& data) = 0;
};

// Derived class for n-Day Moving Average (DMA) indicator
class DMAIndicator : public Indicator {
private:
    int n;
    vector<double> dma;

public:
    DMAIndicator(int n) : n(n) {}

    void calculate(const StockData& data) override {
        dma.clear();
        int startidx = data.startidx;
        dma.resize(startidx+1);

        double sum = 0;
        for (int i=0; i<n; i++) {
            sum += data.close[i];
        }
        dma[0] = sum / n;

        for (int i = 1; i <= startidx; i++) {
            sum += (data.close[i+n-1] - data.close[i-1]);
            dma[i] = sum / n;
        }
    }

    const vector<double>& getDMA() const {
        return dma;
    }
};

// Derived class for Standard Deviation (SD) indicator
class SDIndicator : public Indicator {
private:
    int n;
    vector<double> sd;

public:
    SDIndicator(int n) : n(n) {}

    void calculate(const StockData& data) override {
        sd.clear();
        int startidx = data.startidx;
        sd.resize(startidx+1);

        double sum = 0;
        double sqsum = 0;
        for (int i=0; i<n; i++) {
            sum += data.close[i];
            sqsum += data.close[i]*data.close[i];
        }
        double mean = sum / n;
        sd[0] = sqrt(sqsum / n - mean * mean);

        for (int i = 1; i <= startidx; i++) {
            sum += (data.close[i+n-1] - data.close[i-1]);
            sqsum += (data.close[i+n-1]*data.close[i+n-1] - data.close[i-1]*data.close[i-1]);
            mean = sum / n;
            sd[i] = sqrt(sqsum / n - mean * mean);
        }
    }

    const vector<double>& getSD() const {
        return sd;
    }
};

class AMAIndicator : public Indicator {
private:
    int n;
    double c1;
    double c2;
    double SF0;
    vector<double> ama;
    
public:
    AMAIndicator(int n, double c1, double c2, double SF0=0.5) : n(n), c1(c1), c2(c2), SF0(SF0) {}

    void calculate(const StockData& data) override{
        cout << c1 << ' ' << c2 << endl;
        ama.clear();
        int startidx = data.startidx;
        ama.resize(startidx+1);

        ama[startidx] = data.close[startidx];

        double SFt = SF0;

        double abssum = 0;
        for (int i=startidx-1; i<startidx+n-1; i++) {
            abssum += abs(data.close[i] - data.close[i+1]);
        }
        double ER = abs(data.close[startidx-1] - data.close[startidx-1+n])/abssum;
        SFt = SFt + c1 * ( ((( 2*ER /(1 + c2)) - 1)/(2 * ER / (1 + c2) + 1)) - SFt);
        ama[startidx-1] = ama[startidx] + SFt * (data.close[startidx-1] - ama[startidx]);
        
        cout << data.date[startidx-1] <<  " "<<ama[startidx-1]*(1.0 - (5 / 100.0))<<" "<<ama[startidx-1]*(1.0 + (5 / 100.0))<<" " << data.close[startidx-1] << " " << abssum << " " << ER<< " " << SFt << " " << ama[startidx-1]<< "\n";
        for (int i = startidx-2; i>=0; i--) {
            abssum += (abs(data.close[i] - data.close[i+1]) - abs(data.close[i+n] - data.close[i+n+1]));
            ER = abs(data.close[i] - data.close[i+n])/abssum;
            SFt = SFt + c1 * ( ((( 2*ER /(1 + c2)) - 1)/(2 * ER / (1 + c2) + 1)) - SFt);
            ama[i] = ama[i+1] + SFt * (data.close[i] - ama[i+1]);
            cout << data.date[i] <<  " "<<ama[i]*(1.0 - (5 / 100.0))<<" "<<ama[i]*(1.0 + (5 / 100.0))<<" " << data.close[i] << " " << abssum  << " " << ER<< " " << SFt << " " << ama[i]<< "\n";
        }
    }

    const vector<double>& getAMA() const {
        return ama;
    }
};


class MACDIndicator : public Indicator {
private:
    double alpha_short = 2.0 / 13; 
    double alpha_long = 2.0 / 27;
    double alpha_signal = 2.0 / 10;
    vector<double> short_ewm;
    vector<double> long_ewm;
    vector<double> macd;
    vector<double> signal;

public:
    MACDIndicator() {}

    void calculate(const StockData& data) override{
        short_ewm.clear();
        long_ewm.clear();
        macd.clear();
        signal.clear();

        int startidx = data.startidx;
        short_ewm.resize(startidx+1);
        long_ewm.resize(startidx+1);
        macd.resize(startidx+1);
        signal.resize(startidx+1);

        short_ewm[startidx] = data.close[startidx];
        for (int i = startidx-1; i>=0; i--) {
            short_ewm[i] = alpha_short * (data.close[i] - short_ewm[i+1]) + short_ewm[i+1];
        }

        // Calculate Long EWM (26-day)
        long_ewm[startidx] = data.close[startidx];
        for (int i = startidx-1; i>=0; i--) {
            long_ewm[i] = alpha_long * (data.close[i] - long_ewm[i+1]) + long_ewm[i+1];
        }

        // Calculate MACD = Short_EWM - Long_EWM
        for (int i=0; i <= startidx; i++) {
            macd[i] = short_ewm[i] - long_ewm[i];
        }

        // Calculate Signal Line (9-day EWM of MACD)
        signal[startidx] = macd[startidx];
        for (int i = startidx-1; i>=0; i--) {
            signal[i] = alpha_signal * (macd[i] - signal[i+1]) + signal[i+1];
        }
    }

    const vector<double>& getMACD() const {
        return macd;
    }

    const vector<double>& getSignalLine() const {
        return signal;
    }
};


class RSIIndicator : public Indicator {
private:
    int n;
    vector<double> rsi;

public:
    RSIIndicator(int n) : n(n) {}

    void calculate(const StockData& data) {
        rsi.clear();
        int startidx = data.startidx;
        rsi.resize(startidx+1);

        // Calculate average gain and average loss
        double gain = 0.0;
        double loss = 0.0;
        for (int i = startidx; i < startidx+n; i++) {
            double change = data.close[i] - data.close[i + 1];
            if (change > 0) {
                gain += change;
            }
            else {
                loss -= change;
            }
        }

        double RS = (loss == 0) ? -1.0 : gain / loss;

        // Calculate RSI
        rsi[startidx] = (loss == 0) ? 100.0 : 100.0 - 100.0 / (1.0 + RS);

        for (int i = startidx-1; i>=0; i--) {
            double change = data.close[i] - data.close[i + 1];
            if (change > 0) {
                gain += change;
            }
            else {
                loss -= change;
            }
            change = data.close[i+n] - data.close[i + n + 1];
            if (change > 0) {
                gain -= change;
            }
            else {
                loss += change;
            }
            RS = (loss == 0) ? -1.0 : gain / loss;
            rsi[i] = (loss == 0) ? 100.0 : 100.0 - 100.0 / (1.0 + RS);
        }
    }

    const vector<double>& getRSI() const {
        return rsi;
    }
};



class ADXIndicator : public Indicator {
private:
    int n;
    vector<double> tr;
    vector<double> dm_plus;
    vector<double> dm_minus;
    vector<double> atr;
    vector<double> di_plus;
    vector<double> di_minus;
    vector<double> dx;
    vector<double> dx_final;
    vector<double> adx;

public:
    ADXIndicator(int n) : n(n) {}

    void calculate(const StockData& data) override{
        tr.clear();
        dm_plus.clear();
        dm_minus.clear();
        atr.clear();
        di_plus.clear();
        di_minus.clear();
        dx.clear();
        dx_final.clear();
        adx.clear();

        int startidx = data.startidx;
        tr.resize(startidx+1);
        dm_plus.resize(startidx+1);
        dm_minus.resize(startidx+1);
        atr.resize(startidx+1);
        di_plus.resize(startidx+1);
        di_minus.resize(startidx+1);
        dx.resize(startidx+1);
        dx_final.resize(startidx+1);
        adx.resize(startidx+1);

        // Calculate True Range (TRt) and Directional Movement (DM+ and DM-)
        for (int i = 0; i <= startidx; i++) {
            double tr_high_low = data.high[i] - data.low[i];
            double tr_high_prev_close = abs(data.high[i] - data.close[i+1]);
            double tr_low_prev_close = abs(data.low[i] - data.close[i+1]);
            tr[i] = max(tr_high_low, max(tr_high_prev_close, tr_low_prev_close));

            double dm_up = data.high[i] - data.high[i+1];
            double dm_down = data.low[i] - data.low[i+1];
            dm_plus[i] = max(0.0,dm_up);
            dm_minus[i] = max(0.0,dm_down);
        }

        double alpha = 2.0/ (n+1);
        
        atr[startidx] = tr[startidx];
        for (int i = startidx-1; i>=0; i--) {
            atr[i] = alpha * (tr[i] - atr[i+1]) + atr[i+1];
        }

        di_plus[startidx] = dm_plus[startidx]/atr[startidx];
        for (int i = startidx-1; i>=0; i--) {
            di_plus[i] = alpha * (dm_plus[i]/atr[i] - di_plus[i+1]) + di_plus[i+1];
        }
        di_minus[startidx] = dm_minus[startidx]/atr[startidx];
        for (int i = startidx-1; i>=0; i--) {
            di_minus[i] = alpha * (dm_minus[i]/atr[i] - di_minus[i+1]) + di_minus[i+1];
        }

        for (int i = 0; i <= startidx; i++) {
            if ((di_plus[i] + di_minus[i])==0){
                dx[i] = 0;
                dx_final[i] = nan("1");
            }
            else{
                dx[i] = ((di_plus[i] - di_minus[i]) / (di_plus[i] + di_minus[i])) * 100;
                dx_final[i] = dx[i];
            }
        }

        adx[startidx] = dx[startidx];
        for (int i = startidx-1; i>=0; i--) {
            adx[i] = alpha * (dx[i] - adx[i+1]) + adx[i+1];
        }
    }

    const vector<double>& getADX() const {
        return adx;
    }
    const vector<double>& getDX() const {
        return dx_final;
    }
};

#endif // INDICATORS_H