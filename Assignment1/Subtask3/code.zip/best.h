#ifndef BESTOFALL_H
#define BESTOFALL_H

#include "strategy.h"
#include "basic.h" 

#include <vector>
#include <pthread.h>

class BestOfAll : public Strategy {
private:
    vector<OrderStatistics> orderStats;
    vector<DailyCashFlow> dailyCashflows;
    int x=5;
    double adx_threshold=25;
    double oversold_threshold=25;
    double overbought_threshold=25;
    int max_hold_days=28;
    double c1=2, c2=0.2;
    string train_start_date="", train_end_date="";
    struct ThreadData {
        Strategy* strategy;
        StockData* stockData;
    };

  
    static void* threadFunc(void* arg) {
        auto data = static_cast<std::pair<Strategy*, StockData>*>(arg);
        auto strategy = data->first;
        auto stockData = data->second;
        strategy->implementStrategy(stockData);
        return nullptr;
    }


public:
    BestOfAll(const string& symbol, const string& start_date, const string& end_date)
        : Strategy(symbol, start_date, end_date) {}

    void implementStrategy(const StockData& stockData) override {
        
        Basic basicStrategy(symbol, start_date, end_date, 7, x);
        DMATrend dma_strategy(symbol, start_date, end_date, 50, x, 2);
        ImprovedDMAStrategy dma_plus_plus_strategy(symbol, start_date, end_date, x, 5, 14, max_hold_days, c1, c2);
        MACDStrategy macd_strategy(symbol, start_date, end_date, x);
        RSIStrategy rsi_strategy(symbol, start_date, end_date, 14, x, oversold_threshold, overbought_threshold);
        ADXStrategy adx_strategy(symbol, start_date, end_date, 14, x, adx_threshold);
        LinearRegressionStrategy linear_regression_strategy(symbol, start_date, end_date, x, 2, train_start_date, train_end_date);
       
        pthread_t threads[7]; 
        std::pair<Strategy*, StockData> threadData[7];

        threadData[0] = std::make_pair(&basicStrategy, stockData);  
        threadData[1] = std::make_pair(&dma_strategy, stockData);  
        threadData[2] = std::make_pair(&dma_plus_plus_strategy, stockData);  
        threadData[3] = std::make_pair(&macd_strategy, stockData);  
        threadData[4] = std::make_pair(&rsi_strategy, stockData);  
        threadData[5] = std::make_pair(&adx_strategy, stockData);  
        threadData[6] = std::make_pair(&linear_regression_strategy, stockData);  
       
        for (int i = 0; i < 7; ++i) { 
            pthread_create(&threads[i], nullptr, threadFunc, &threadData[i]);
        }
       
      
        for (int i = 0; i < 7; ++i) { 
            pthread_join(threads[i], nullptr);
        }
       
    
        int max_index=0;
        double max_pnl=-1e9;
        for(int i=0;i<7;i++){
            cout<<i<<" "<<threadData[i].first->finalpnl<<endl;
            if(threadData[i].first->finalpnl>max_pnl){
                max_index=i;
                max_pnl=threadData[i].first->finalpnl;
            }
        }
        cout<<max_index<<" this is the max index"<<endl;
        auto best_strategy=threadData[max_index].first;
        best_strategy->writeOrderStatistics(best_strategy->orderStats);
        best_strategy->writeDailyCashflow(best_strategy->dailyCashflows);
        best_strategy->writeFinalPnL(best_strategy->finalpnl);
      
        cout << "DONE" << endl;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing BestOfAll Strategy" << endl;
        implementStrategy(stockData);
       
    }
};



#endif 
