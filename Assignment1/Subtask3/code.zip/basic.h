// basic.h
#ifndef BASIC_H
#define BASIC_H

#include "strategy.h"

class Basic : public Strategy {
private:
    int n;
    int x;

    void get_trend(int N, vector<int>& trend_direction, vector<int>& trend_duration, const StockData& stockData){
        //BASE CASE
        if (stockData.close[N-2] > stockData.close[N-1] + 1e-8){
            trend_direction[N-2] = 1;
        }
        else if (stockData.close[N-2] < stockData.close[N-1] - 1e-8){
            trend_direction[N-2] = -1;
        }
        else{
            trend_direction[N-2] = 0;
        }
        trend_duration[N-2] = 1;

        //ITERATIVE CASES
        for (int i = N-3; i>=0; i--){
            int cur_trend_duration = trend_duration[i+1];
            if (stockData.close[i] > stockData.close[i+1] + 1e-8){
                if (trend_direction[i+1]==1){
                    trend_duration[i] = cur_trend_duration+1;
                }
                else{
                    trend_duration[i] = 1;
                }
                trend_direction[i] = 1;
            }
            else if (stockData.close[i] < stockData.close[i+1] - 1e-8){
                if (trend_direction[i+1]==-1){
                    trend_duration[i] = cur_trend_duration+1;
                }
                else{
                    trend_duration[i] = 1;
                }
                trend_direction[i] = -1;
            }
            else{
                if (trend_direction[i+1]==0){
                    trend_duration[i] = cur_trend_duration+1;
                }
                else{
                    trend_duration[i] = 1;
                }
                trend_direction[i] = 0;
            }
        }
        return;
    }

public:
    Basic(const string& symbol, const string& start_date, const string& end_date, int n, int x)
        : Strategy(symbol, start_date, end_date), n(n), x(x) {}

    void implementStrategy(const StockData& stockData) override {
        int startidx = stockData.startidx;
        int N = stockData.date.size();
        double CashInHand = 0;
        int position = 0;
        int quantity = 1;
        vector<int> trend_direction(N-1);
        vector<int> trend_duration(N-1);

        get_trend(N, trend_direction, trend_duration, stockData);

        // for (int i = N-2; i >=0; i--){
        //     cout << trend_direction[i] << ' ' << trend_duration[i] << ' ' << stockData.date[i] << ' ' << stockData.close[i] << endl;
        // }

        for (int day = startidx; day>=0; day--){
            if (trend_duration[day] >= n){
                if (trend_direction[day]==1 and position<x){
                    orderStats.emplace_back(stockData.date[day], "BUY", quantity, stockData.close[day]);
                    position++;
                    CashInHand -= quantity * stockData.close[day];
                }
                else if (trend_direction[day]==-1 and position>-x){
                    orderStats.emplace_back(stockData.date[day], "SELL", quantity, stockData.close[day]);
                    position--;
                    CashInHand += quantity * stockData.close[day];
                }
            }
            dailyCashflows.emplace_back(stockData.date[day], CashInHand);
        }

        // SQUARE-OFF
        CashInHand += position * stockData.close[0];
        finalpnl = CashInHand;
        cout << "DONE" << endl;
        return;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing Basic Strategy" << endl;
        implementStrategy(stockData);
        writeOrderStatistics(orderStats);
        writeDailyCashflow(dailyCashflows);
        writeFinalPnL(finalpnl);
    }
};
#endif // BASIC_H
