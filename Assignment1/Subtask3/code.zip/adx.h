#ifndef ADX_STRATEGY_H
#define ADX_STRATEGY_H
#include "strategy.h"
#include "indicators.h"

class ADXStrategy : public Strategy {
private:
    int n;
    int x;
    double adx_threshold;
    
public:
    ADXStrategy(const string& symbol, const string& start_date, const string& end_date, int n, int x, double adx_threshold)
        : Strategy(symbol, start_date, end_date), n(n), x(x), adx_threshold(adx_threshold) {}

    void implementStrategy(const StockData& stockData) override {
        int startidx = stockData.startidx;
        double CashInHand = 0;
        int position = 0;
        int quantity = 1;

        ADXIndicator adxIndicator(n); 
        adxIndicator.calculate(stockData);
        const vector<double>& adx = adxIndicator.getADX();
        const vector<double>& dx = adxIndicator.getDX();


        for (int day = startidx; day >= 0; day--) {
            cout << stockData.date[day] << ' ' << stockData.close[day] << ' ' << adx[day] << ' ' << dx[day]<< endl; 
        }
        cout << "T " << adx_threshold << endl;

        for (int day = startidx; day >= 0; day--) {
            if (adx[day] > adx_threshold && position < x && !(isnan(dx[day]))) { // Buy condition
                cout << stockData.date[day] << ' ' << adx_threshold << endl;
                orderStats.emplace_back(stockData.date[day], "BUY", quantity, stockData.close[day]);
                position++;
                CashInHand -= quantity * stockData.close[day];
            } else if (adx[day] < adx_threshold && position > -x && !(isnan(dx[day]))) { // Sell condition
                orderStats.emplace_back(stockData.date[day], "SELL", quantity, stockData.close[day]);
                position--;
                CashInHand += quantity * stockData.close[day];
            }
            dailyCashflows.emplace_back(stockData.date[day], CashInHand);
        }

        // Square off
        CashInHand += position * stockData.close[0];
        finalpnl = CashInHand;
        cout << "DONE" << endl;
    }

    void execute(const StockData& stockData) override {
        cout << "Executing ADX Strategy" << endl;
        implementStrategy(stockData);
        writeOrderStatistics(orderStats);
        writeDailyCashflow(dailyCashflows);
        writeFinalPnL(finalpnl);
    }
};

#endif // ADX_STRATEGY_H
