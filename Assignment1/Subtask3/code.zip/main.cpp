#include <iostream>
#include <string>
#include <vector>

// Include header files for each strategy
#include "basic.h"
#include "dma.h"
#include "dma++.h"
#include "macd.h"
#include "rsi.h"
#include "adx.h"
#include "linear_regression.h"
#include "best.h"
#include "pairs.h"
#include "best.h"
using namespace std;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " --strategy=<strategy_name> [optional_arguments]" << endl;
        return 1;
    }

    string strategy;
    int startidx;
    string symbol;
    string start_date;
    string end_date;
    int n=50;
    int x;
    double p;
    double oversold_threshold;
    double overbought_threshold;
    int max_hold_days;
    double c1;
    double c2;
    double adx_threshold;
    double stop_loss_threshold;
    string symbol1;
    string symbol2;
    int threshold;
    string train_start_date;
    string train_end_date;

    // Parse command-line arguments
    for (int i = 1; i < argc; ++i) {
        string arg = argv[i];
        if (arg.substr(0, 11) == "--strategy=") {
            strategy = arg.substr(11);
        } else if (arg.substr(0, 11) == "--startidx=") {
            startidx = stoi(arg.substr(11));
        } else if (arg.substr(0, 9) == "--symbol=") {
            symbol = arg.substr(9);
        } else if (arg.substr(0, 13) == "--start_date=") {
            start_date = arg.substr(13);
        } else if (arg.substr(0, 11) == "--end_date=") {
            end_date = arg.substr(11);
        } else if (arg.substr(0, 4) == "--n=") {
            n = stoi(arg.substr(4));
        } else if (arg.substr(0, 4) == "--x=") {
            x = stoi(arg.substr(4));
        } else if (arg.substr(0, 4) == "--p=") {
            p = stod(arg.substr(4));
        } else if (arg.substr(0, 21) == "--oversold_threshold=") {
            oversold_threshold = stod(arg.substr(21));
        } else if (arg.substr(0, 23) == "--overbought_threshold=") {
            overbought_threshold = stod(arg.substr(23));
        } else if (arg.substr(0, 16) == "--max_hold_days=") {
            max_hold_days = stoi(arg.substr(16));
        } else if (arg.substr(0, 5) == "--c1=") {
            c1 = stod(arg.substr(5));
        } else if (arg.substr(0, 5) == "--c2=") {
            c2 = stod(arg.substr(5));
        } else if (arg.substr(0, 16) == "--adx_threshold=") {
            adx_threshold = stod(arg.substr(16));
        } else if (arg.substr(0, 22) == "--stop_loss_threshold=") {
            if (arg.length()==22) stop_loss_threshold = -1.0;
            else stop_loss_threshold = stod(arg.substr(22));
        } else if (arg.substr(0, 10) == "--symbol1=") {
            symbol1 = arg.substr(10);
        } else if (arg.substr(0, 10) == "--symbol2=") {
            symbol2 = arg.substr(10);
        } else if (arg.substr(0, 12) == "--threshold=") {
            threshold = stoi(arg.substr(12));
        } else if (arg.substr(0, 19) == "--train_start_date=") {
            train_start_date = arg.substr(19);
        } else if (arg.substr(0, 17) == "--train_end_date=") {
            train_end_date = arg.substr(17);
        }
    }
    cout << "here" << endl;
    StockData stockData;
    StockData stockData1;
    StockData stockData2;

    if (strategy=="PAIRS"){
        stockData1 = StockData(strategy, symbol1, startidx);
        stockData2 = StockData(strategy, symbol2, startidx);
    }
    else stockData = StockData(strategy, symbol, startidx);

    // Execute the selected strategy
    if (strategy == "BASIC") {
        Basic basic_strategy(symbol, start_date, end_date, n, x);
        basic_strategy.execute(stockData); // Assuming you have a way to obtain stockData
    }
    else if (strategy == "DMA") {
        DMATrend dma_strategy(symbol, start_date, end_date, n, x, p);
        dma_strategy.execute(stockData);
    }
    else if (strategy == "DMA++") {
        ImprovedDMAStrategy dma_plus_plus_strategy(symbol, start_date, end_date, x, p, n, max_hold_days, c1, c2);
        dma_plus_plus_strategy.execute(stockData);
    }
    else if (strategy == "MACD") {
        MACDStrategy macd_strategy(symbol, start_date, end_date, x);
        macd_strategy.execute(stockData);
    }
    else if (strategy == "RSI") {
        //cout << x  << ' '<< oversold_threshold << ' ' << overbought_threshold << ' ' << n << endl;
        RSIStrategy rsi_strategy(symbol, start_date, end_date, n, x, oversold_threshold, overbought_threshold);
        rsi_strategy.execute(stockData);
    }
    else if (strategy == "ADX") {
        ADXStrategy adx_strategy(symbol, start_date, end_date, n, x, adx_threshold);
        adx_strategy.execute(stockData);
    }
    else if (strategy == "LINEAR_REGRESSION") {
        // Assuming you implement this strategy similarly
        LinearRegressionStrategy linear_regression_strategy(symbol, start_date, end_date, x, p, train_start_date, train_end_date);
        linear_regression_strategy.execute(stockData);
    }
    else if (strategy == "BEST_OF_ALL") {
        cout << "her" << endl;
        BestOfAll best_of_all_strategy(symbol, start_date, end_date);
        best_of_all_strategy.execute(stockData);
    }
    else if (strategy == "PAIRS") {
        PairsTradingStrategy pairs_strategy(symbol1, symbol2, x, n, threshold, stop_loss_threshold, start_date, end_date);
        pairs_strategy.execute(stockData1, stockData2);
    }
    else {
        cerr << "Invalid strategy specified: " << strategy << endl;
        return 1;
    }
    string filename = symbol + ".csv";
    //remove(filename.c_str());

    return 0;
}
