#ifndef PAIRSTRADINGSTRATEGY_H
#define PAIRSTRADINGSTRATEGY_H

#include <iostream>
#include <vector>
#include <cmath>
#include <queue>
#include "strategy.h"
#include "indicators.h"

using namespace std;

struct Trades {
    double dma;
    double sd;
    int direction;
    bool open;
    Trades(double dma_value, double sd_value, int dir, bool isOpen)
        : dma(dma_value), sd(sd_value), direction(dir), open(isOpen) {}
};

class PairsTradingStrategy {
private:
    string symbol1;
    string symbol2;
    string start_date;
    string end_date;
    int x;
    int n;
    double threshold;
    double stop_loss_threshold;
    vector<OrderStatistics> orderStats1;
    vector<OrderStatistics> orderStats2;
    vector<DailyCashFlow> dailyCashflows;

public:
    PairsTradingStrategy(const string& symbol1, const string& symbol2, int x, int n, double threshold, double stop_loss_threshold, const string& start_date, const string& end_date)
        : symbol1(symbol1), symbol2(symbol2), x(x), n(n), threshold(threshold), stop_loss_threshold(stop_loss_threshold), start_date(start_date), end_date(end_date) {
            string dailyCashflowsfile = "daily_cashflow.csv";
            string order1file = "order_statistics_1.csv";
            string order2file = "order_statistics_2.csv";
            string pnlfile = "final_pnl.txt";
            remove(dailyCashflowsfile.c_str());
            remove(order1file.c_str());
            remove(order2file.c_str());
            remove(pnlfile.c_str());
        }

    // Method to write order statistics
    void writeOrderStatistics(const vector<OrderStatistics>& orders, const string& filename = "order_statistics.csv") {
        ofstream outFile(filename, ios::app);
        outFile << "Date" << "," << "Order_dir" << "," << "Quantity" << "," << "Price" << endl;
        if (outFile.is_open()) {
            for (const auto& order : orders) {
                outFile << order.date << "," << order.direction << "," << order.quantity << "," << order.price << endl;
            }
            outFile.close();
        } else {
            cerr << "Error opening file for writing order statistics." << endl;
        }
    }

    // Method to write daily cashflow
    void writeDailyCashflow(const vector<DailyCashFlow>& cashflows, const string& filename = "daily_cashflow.csv") {
        ofstream outFile(filename, ios::app);
        outFile << "Date" << "," << "Cashflow" << endl;
        if (outFile.is_open()) {
            for (const auto& cash : cashflows) {
                outFile << cash.date << "," << to_string(cash.cashflow) << endl;
            }
            outFile.close();
        } else {
            cerr << "Error opening file for writing daily cash flow." << endl;
        }
    }

    // Method to write final PnL
    void writeFinalPnL(double pnl, const string& filename = "final_pnl.txt") {
        ofstream outFile(filename);
        if (outFile.is_open()){
            outFile << pnl;
            outFile.close();
        }
        else{
            cerr << "Error opening file for writing final PnL." << endl;
        }
    }

    void implementStrategy(const StockData& stockData, const StockData& stockData1, const StockData& stockData2) {
        int startidx = stockData.startidx;
        cout << x << endl;
        double CashInHand = 0;
        int position = 0;
        int quantity = 1;

        DMAIndicator dmaIndicator(n); 
        dmaIndicator.calculate(stockData);
        const vector<double>& dma = dmaIndicator.getDMA();

        // Create an instance of SDIndicator
        SDIndicator sdIndicator(n); 
        sdIndicator.calculate(stockData);
        const vector<double>& sd = sdIndicator.getSD();

        for (int i = startidx; i >=0; i--){
            cout << stockData.date[i] << ' ' << stockData.close[i] << ' ' << dma[i] << ' ' << sd[i]  << " ZSCORE " << (stockData.close[i] - dma[i])/sd[i] << endl;
        }

        if (stop_loss_threshold == -1){
            // Implement strategy based on DMA and standard deviation
            for (int day = startidx; day >= 0; day--){
                if ((stockData.close[day] - dma[day])/sd[day] > threshold and position > -x) {
                    orderStats1.emplace_back(stockData.date[day], "SELL", quantity, stockData1.close[day]);
                    orderStats2.emplace_back(stockData.date[day], "BUY", quantity, stockData2.close[day]);
                    position -= quantity;
                    CashInHand += quantity * stockData.close[day];
                }
                else if ((stockData.close[day] - dma[day])/sd[day] < -threshold and position < x) {
                    orderStats1.emplace_back(stockData.date[day], "BUY", quantity, stockData1.close[day]);
                    orderStats2.emplace_back(stockData.date[day], "SELL", quantity, stockData2.close[day]);
                    position += quantity;
                    CashInHand -= quantity * stockData.close[day];
                }

                dailyCashflows.emplace_back(stockData.date[day], CashInHand);
            }
        }
        else{

            int open_dir=0;
            int open_index=0;
            vector<Trades> trades;

            for (int day = startidx; day >= 0; day--){
                int today_quantity = 0;
                if ((stockData.close[day] - dma[day])/sd[day] >= threshold and position > -x) {
                    today_quantity--;
                    position -= quantity;
                    CashInHand += quantity * stockData.close[day];
                    if (open_dir==-1){
                        trades.emplace_back(dma[day], sd[day], -1, true);
                    }
                    else if (open_dir==0){
                        open_dir=-1;
                        trades.emplace_back(dma[day], sd[day], -1, true);
                        open_index=0;
                    }
                    else{
                        open_index++;
                        if (open_index==trades.size()){
                            trades.clear();
                            open_index=0;
                            open_dir=0;
                            break;
                        }
                        while (!trades[open_index].open){
                            open_index++;
                            if (open_index==trades.size()){
                                trades.clear();
                                open_index=0;
                                open_dir=0;
                                break;
                            }
                        }
                    }
                }
                else if ((stockData.close[day] - dma[day])/sd[day] <= -threshold and position < x) {
                    today_quantity++;
                    position += quantity;
                    CashInHand -= quantity * stockData.close[day];
                    if (open_dir==1){
                        trades.emplace_back(dma[day], sd[day], 1, true);
                    }
                    else if (open_dir==0){
                        open_dir=1;
                        trades.emplace_back(dma[day], sd[day], 1, true);
                        open_index=0;
                    }
                    else{
                        open_index++;
                        if (open_index==trades.size()){
                            trades.clear();
                            open_index=0;
                            open_dir=0;
                            break;
                        }
                        while (!trades[open_index].open){
                            open_index++;
                            if (open_index==trades.size()){
                                trades.clear();
                                open_index=0;
                                open_dir=0;
                                break;
                            }
                        }
                    }
                }

                for (int i=open_index; i<trades.size(); i++){
                    if ((stockData.close[day] - trades[i].dma)/trades[i].sd >= stop_loss_threshold and trades[i].open and trades[i].direction==-1) {
                        today_quantity++;
                        position += quantity;
                        CashInHand -= quantity * stockData.close[day];
                        trades[i].open = false;
                    }
                    else if ((stockData.close[day] - trades[i].dma)/trades[i].sd <= -stop_loss_threshold and trades[i].open and trades[i].direction==1) {
                        today_quantity--;
                        position -= quantity;
                        CashInHand += quantity * stockData.close[day];
                        trades[i].open = false;
                    }
                }
                if (today_quantity<0){
                    orderStats1.emplace_back(stockData.date[day], "SELL", -today_quantity, stockData1.close[day]);
                    orderStats2.emplace_back(stockData.date[day], "BUY", -today_quantity, stockData2.close[day]);
                }
                else if (today_quantity>0){
                    orderStats1.emplace_back(stockData.date[day], "BUY", today_quantity, stockData1.close[day]);
                    orderStats2.emplace_back(stockData.date[day], "SELL", today_quantity, stockData2.close[day]);
                }

                dailyCashflows.emplace_back(stockData.date[day], CashInHand);
            }
        }

        CashInHand += position * stockData.close[0];
        writeFinalPnL(CashInHand);
        cout << "DONE" << endl;
    }

    void execute(const StockData& stockData1, const StockData& stockData2) {
        cout << "Executing Pairs Trading Strategy" << endl;
        StockData stockData("PAIRS", "", -2);
        stockData.startidx = stockData1.startidx;

        // Calculate spread between the prices of the two stocks
        for (int i = 0; i < stockData1.close.size(); ++i) {
            stockData.close.push_back(stockData1.close[i] - stockData2.close[i]);
            stockData.date.push_back(stockData1.date[i]);
        }
        implementStrategy(stockData, stockData1, stockData2);
        writeOrderStatistics(orderStats1, "order_statistics_1.csv");
        writeOrderStatistics(orderStats2, "order_statistics_2.csv");
        writeDailyCashflow(dailyCashflows);
    }
};

#endif // PAIRSTRADINGSTRATEGY_H
