from moviepy.editor import VideoFileClip
import whisper
import fitz

def extract_audio(input, output):
    video = VideoFileClip(input)
    if video.audio is None:
        print(f"The video file at {input} does not contain an audio track.")
        return
    video.audio.write_audiofile(output)

input = "/mnt/c/Satwik/IITD_CS5/Courses/SEM4/COL290/assignment2/subtask1/example_video2.mp4"
output = "/mnt/c/Satwik/IITD_CS5/Courses/SEM4/COL290/assignment2/subtask1/example_video2.wav"
# extract_audio(input,output)

def transcribe_audio(input,output):
    model = whisper.load_model("base")
    result = model.transcribe(input)

    with open(output,"w") as file:
        file.write(result["text"])

audio_input = "/mnt/c/Satwik/IITD_CS5/Courses/SEM4/COL290/assignment2/subtask1/example_video2.wav"
text_output = "/mnt/c/Satwik/IITD_CS5/Courses/SEM4/COL290/assignment2/subtask1/example_video2.txt"
# transcribe_audio(audio_input,text_output)

def text_from_pdf(input_pdf_path, output_text_path):
    with fitz.open(input_pdf_path) as f, open(output_text_path, "w") as output_file:
        for page in f:
            text = page.get_text()
            output_file.write(text)

# Example usage
text_input = "/mnt/c/Satwik/IITD_CS5/Courses/SEM4/COL290/assignment2/subtask1/test2.pdf"
text_output = "/mnt/c/Satwik/IITD_CS5/Courses/SEM4/COL290/assignment2/subtask1/test2.txt"
# text_from_pdf(text_input, text_output)